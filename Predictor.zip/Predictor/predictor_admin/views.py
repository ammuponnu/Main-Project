from django.shortcuts import render, HttpResponse
from django.db import connection
# Create your views here.
def admin_home(request):
    cursor = connection.cursor()
    u = request.POST.get('username')
    p = request.POST.get('password')
    sql1 = "select * from admin_login where username='%s' and password='%s'" % (u, p)
    cursor.execute(sql1)
    if cursor.rowcount > 0:
        request.session['username'] = u
        request.session['password'] = p
        return render(request, 'predictor_admin/admin_login.html')
    return render(request, 'predictor_admin/admin_home.html')

def admin_login(request):
    return render(request, 'predictor_admin/admin_login')

def Faculty_details(request):
    if request.method=='POST':
        cursor = connection.cursor()
        a=request.POST.get('email')
        sql2 = "UPDATE reg SET stat = 'Y' WHERE Email = '%s'" % (a)
        cursor.execute(sql2)
        html = "<script>alert('successfully changed! ');window.location='/predictor_admin/Faculty_details/';</script>"
        return HttpResponse(html)
    else:
        cursor = connection.cursor()
        list = []
        sql1 = "select * from reg"
        cursor.execute(sql1)
        m = cursor.fetchall()
        for row in m:
            dict = {'id':row[0], 'FirstName': row[1], 'LastName': row[2], 'Email': row[3], 'gender':row[5], 'mobno': row[6], 'dept': row[7], 'POSITION':row[8], 'stat': row[9]}
            list.append(dict)
    return render(request, 'predictor_admin/Faculty_details.html', {'list':list})
def Add_subject(request):
    if request.method=='POST':
        i=10
    else:
        c = request.GET['c']
        l=[]
        list = []
        li = []
        cursor =connection.cursor()
        sql = "select * from course where cid='%s'" % (c)
        cursor.execute(sql)
        m=cursor.fetchall()
        sql1 = "select * from class where cid='%s'" % (c)
        cursor.execute(sql1)
        n = cursor.fetchall()

        for i in m:
            d = {'cid': i[0], 'cname': i[1]}
            l.append(d)

        for j in n:
            dict = {'cl_id': j[0], 'cname': j[1]}
            list.append(dict)

    return render(request, 'predictor_admin/Add_subject.html', {'l':l, 'list':list})

'''def class_id(request):
    cursor = connection.cursor()
    cid = request.GET('cid')
    sql="select * from class where cid='%s'" % (cid)
    cursor.execute(sql)
    n = cursor.fetchall()
    for i in n:
        dict = {'cl_id': i[0], 'cname': i[1]}
        list.append(dict)
    return render(request, 'predictor_admin/Add_subject.html', {'list':list})'''

def subject_det(request):
    list = []
    cursor = connection.cursor()
    sql = "select * from course"
    cursor.execute(sql)
    m = cursor.fetchall()
    for i in m:
        d = {'cid': i[0], 'cname': i[1]}
        list.append(d)
    return render(request, 'predictor_admin/subject_det.html', {'list': list})

def m_ajax(request):
    if request.method=='POST':
        cursor=connection.cursor()
        s=request.POST.get('c')
        u=request.POST.get('fac')
        v=request.POST.get('sub')
        sql = "INSERT INTO tbl_combine(fid, subid, cl_id) VALUES('%s','%s','%s')" % (u,v,s)
        cursor.execute(sql)
        if cursor.rowcount>0:
            html = "<script>alert('successfully added! ');window.location='/admin_login/m_ajax/';</script>"
            return HttpResponse(html)
    else:
        li=[]
        list=[]
        list1=[]
        c=request.GET['c']
        cursor=connection.cursor()
        sql="SELECT * FROM `subject_details` WHERE subid IN (SELECT subid FROM sub_class where cl_id='%s')" % (c)
        cursor.execute(sql)
        m=cursor.fetchall()
        sql1="SELECT * from class where cl_id='%s'" % (c)
        cursor.execute(sql1)
        n=cursor.fetchall()
        for i in m:
            d = {'subid': i[0], 'subname': i[1]}
            li.append(d)
        for j in n:
            di = {'cl_id': j[0], 'cname': j[1]}
            list.append(di)
        sql2="SELECT fid,FirstName,LastName,Email FROM `reg` WHERE dpt_id IN(SELECT cid FROM class WHERE cid IN(SELECT cid FROM class WHERE cl_id='%s'))" % (c)
        cursor.execute(sql2)
        q=cursor.fetchall()
        for k in q:
            dc={'fid':k[0], 'FirstName':k[1], 'LastName':k[2], 'Email':k[3]}
            list1.append(dc)
    return render(request, 'predictor_admin/m_ajax.html', {'list':list, 'li':li, 'list1':list1})

def timetable(request):
    l=[]
    list=[1,2,3,4,5,6,7]
    cursor=connection.cursor()
    sql="SELECT * FROM course"
    cursor.execute(sql)
    m=cursor.fetchall()
    for j in m:
        d={'cid':j[0],'cname':j[1]}
        l.append(d)
    return render(request, 'predictor_admin/timetable.html', {'list':list, 'l':l})

def request_access(request):
    if request.method=='POST':
        c = request.POST.get('clid')
        d = request.POST.get('d')
        h1 = request.POST.get('h1')
        h2 = request.POST.get('h2')
        h3 = request.POST.get('h3')
        h4 = request.POST.get('h4')
        h5 = request.POST.get('h5')
        h6 = request.POST.get('h6')
        h7 = request.POST.get('h7')
        cursor=connection.cursor()
        sql="insert into timetable(clid,day,h1,h2,h3,h4,h5,h6,h7) values('%s','%s','%s','%s','%s','%s','%s','%s','%s')" % (c,d,h1,h2,h3,h4,h5,h6,h7)
        cursor.execute(sql)
        if cursor.rowcount>0:
            html = "<script>alert('successfully added! ');window.location='/predictor_admin/admin_login/';</script>"
            return HttpResponse(html)
    list=[1,2,3,4,5]
    li=[]
    l=[]
    r=request.GET['c']
    cursor=connection.cursor()
    sql1="select * from course where cid='%s'" % (r)
    cursor.execute(sql1)
    n=cursor.fetchall()
    for j in n:
        dict={'cname': j[1]}
        l.append(dict)
    sql="select * from class where cid='%s'" % (r)
    cursor.execute(sql)
    m=cursor.fetchall()
    for i in m:
        d={'cname': i[1]}
        li.append(d)
    return render(request, 'predictor_admin/request_access.html', {'li':li, 'l':l, 'list':list})
