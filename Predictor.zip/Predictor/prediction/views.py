from django.shortcuts import render, redirect, HttpResponse, HttpResponseRedirect
from django.db import connection
from django.contrib import messages
import logging
from django.urls import reverse
import openpyxl
# Create your views here.
m=''
def index(request):
    request.session['']=''
    return render(request, 'prediction/index.html')

def registration(request):
    if request.method=='POST':
        cursor=connection.cursor()
        fname=request.POST.get('firstname')
        lname=request.POST.get('lastname')
        email=request.POST.get('email')
        password=request.POST.get('password')
        gen=request.POST.get('gender')
        mno=request.POST.get('mobno')
        dpt=request.POST.get('dpt')
        pos=request.POST.get('pos')
        sql1="insert into Reg(FirstName,LastName,Email,password,gender,mobno,POSITION,dpt_id) values ('%s','%s','%s','%s','%s','%s','%s','%s')"%(fname,lname,email,password,gen,mno,pos,dpt)
        cursor.execute(sql1)
        html = "<script>alert('successfully added! ');window.location='/prediction/login/';</script>"
        return HttpResponse(html)
    list=[]
    cursor = connection.cursor()
    sql2="select * from department"
    cursor.execute(sql2)
    m=cursor.fetchall()
    for row in m:
        dict={'dpt_name': row[1]}
        list.append(dict)
    return render(request, 'prediction/registration.html', {'list':list})


def login(request):
    cursor = connection.cursor()
    u = request.POST.get('email')
    p = request.POST.get('password')
    sql1 = "select * from reg where Email='%s' and password='%s'" % (u, p)
    cursor.execute(sql1)
    if cursor.rowcount > 0:
        request.session['Email'] = u
        request.session['password'] = p
        return render(request, 'prediction/home.html')
    return render(request, 'prediction/login.html')

def home(request):
    return render(request, 'prediction/home.html')


def edit(request):
    cursor = connection.cursor()
    list = []
    sql1 = "select * from reg where Email='%s'" % (request.session['Email'])
    cursor.execute(sql1)
    m = cursor.fetchall()
    for row in m:
        dict = {'FirstName': row[1],'LastName': row[2],'Email': row[3],'mobno': row[6],'dept': row[7], 'stat': row[9]}
        list.append(dict)
    return render(request, 'prediction/edit.html', {'list': list})

def facupdate(request):
    if request.method=='POST':
        cursor=connection.cursor()
        m=request.POST.get('email')
        n=request.POST.get('mobno')

        sql="UPDATE reg SET Email='%s',mobno='%s' WHERE Email='%s'" % (m,n,request.session['Email'])
        cursor.execute(sql)
        request.session['Email']=m
        html = "<script>alert('successfully updated! ');window.location='/prediction/home/';</script>"
        return HttpResponse(html)
    cursor = connection.cursor()
    list = []
    sql1 = "select * from reg where Email='%s'" % (request.session['Email'])
    cursor.execute(sql1)
    m = cursor.fetchall()
    for row in m:
        dict = {'FirstName': row[1], 'LastName': row[2], 'Email': row[3], 'mobno': row[6]}
        list.append(dict)
    return render(request, 'prediction/facupdate.html', {'list': list})

def internal(request):
    list=[]
    cursor=connection.cursor()
    sql="SELECT * from class"
    cursor.execute(sql)
    m=cursor.fetchall()
    for row in m:
        d={'cl_id': row[0], 'cname':row[1]}
        list.append(d)
    return render(request, 'prediction/internal.html', {'list':list})
def assessment(request):
    if request.method=='POST':
        cursor=connection.cursor()
        e=request.POST.get('e')
        print(e)
        sub=request.POST.get('sub')
        c=request.POST.get('clid')
        stud=request.POST.get('stud')
        first=request.POST.get('first')
        second=request.POST.get('second')
        ass=request.POST.get('ass')
        project=request.POST.get('project')
        sql="insert into internalmarks(sub,first,second,ass,project,clid,stud_id) values('%s','%s','%s','%s','%s','%s','%s')" % (sub,first,second,ass,project,c,stud)
        cursor.execute(sql)
        html = "<script>alert('successfully added! ');var c={{ c }};window.location='/prediction/assessment/?c='+c;</script>"
        return HttpResponse(html)
    l=[]
    list=[]
    c=request.GET['c']
    cursor=connection.cursor()
    sql="SELECT * FROM tbl_combine WHERE fid='%s' AND cl_id='%s'" % (request.session['Email'],c)
    cursor.execute(sql)
    n=cursor.fetchall()
    sql1="SELECT * FROM student WHERE class IN(SELECT cname FROM class WHERE cl_id='%s')" % (c)
    cursor.execute(sql1)
    m=cursor.fetchall()
    for row in n:
        d={'fid': row[1], 'subid': row[2], 'cl_id': row[3]}
        l.append(d)
    for row in m:
        dict={'stud_id': row[0], 'name': row[1]}
        list.append(dict)
    return render(request, 'prediction/assessment.html', {'l': l, 'list':list})
def mark(request):
    if request.method == 'GET':
        return render(request, 'prediction/mark.html')
    else:
        excel_file = request.FILES["excel_file"]

        # you may put validations here to check extension or file size

        wb = openpyxl.load_workbook(excel_file)
        sheet = wb.active
        excel_data = list()
        # getting a particular sheet by name out of many sheets
        for row in sheet.iter_rows():
            row_data=list()
            for cell in row:
                #dict={'name':cell['name'].value, 'age':cell['age']}
                row_data.append(str(cell.value))
            excel_data.append(row_data)
        print(excel_data)

        return render(request, 'prediction/mark.html', {'excel_data': excel_data})