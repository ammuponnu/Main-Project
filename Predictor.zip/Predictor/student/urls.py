from django.conf.urls import url
from student import views

urlpatterns = [
    url(r'start$', views.start, name="start"),
    url(r'base/$', views.base, name="base"),
    url(r'Regi/$', views.Regi, name="Regi"),
    url(r'Studlogin/$', views.Studlogin, name="Studlogin"),
    url(r'view/$', views.view, name="view"),
    url(r'update/$', views.update, name="update"),
    url(r'internalmarks/$', views.internalmarks, name="internalmarks"),

]