from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.admin_home, name="admin_home"),
    url(r'admin_login/$', views.admin_login, name="admin_login"),
    url(r'Faculty_details/$', views.Faculty_details, name='Faculty_details'),
    url(r'subject_det/', views.subject_det, name='subject_det'),
    url(r'Add_subject/$', views.Add_subject, name='Add_subject'),
    url(r'm_ajax/$', views.m_ajax, name='m_ajax'),
    url(r'timetable/$', views.timetable, name="timetable"),
    url(r'request_access/$', views.request_access, name='request_access'),
    url(r'settings/$', views.settings, name='settings'),
    url(r'predict_dt/$', views.predict_dt, name='predict_dt'),

]
