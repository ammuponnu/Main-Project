from django.apps import AppConfig


class PredictorAdminConfig(AppConfig):
    name = 'predictor_admin'
