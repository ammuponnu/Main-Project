from django.shortcuts import render, redirect, HttpResponse
from django.db import connection
# Create your views here.
'''def base(request):
    if request.method=="POST":
        cursor = connection.cursor()
        rollno = request.POST.get('rollno')
        name = request.POST.get('name')
        gender = request.POST.get('gender')
        email = request.POST.get('email')
        mobno = request.POST.get('mobno')
        dpt = request.POST.get('dpt')
        cl = request.POST.get('cl')
        p = request.POST.get('password')
        sql = "INSERT INTO `student`(`stud_id`, `name`, `gender`, `email`, `mobno`, `dpt`, `class`, `password`) VALUES ('%s','%s','%s','%s','%s','%s','%s','%s')" % (rollno,name,gender,email,mobno,dpt,cl,p)
        cursor.execute(sql)
        html = "<script>alert('successfully added! ');window.location='student/Regi';</script>"
        return HttpResponse(html)
    list = []
    cursor = connection.cursor()
    sql = "select * from course"
    cursor.execute(sql)
    m = cursor.fetchall()
    for i in m:
        d = {'cid': i[0], 'cname': i[1]}
        list.append(d)
    return render(request, 'student/base.html', {'list': list})'''
def studlogin(request):
    return render(request, 'student/studlogin.html')
def Regi(request):
    return render(request, 'student/Regi.html')
def update(request):
    if request.method=='POST':
        cursor=connection.cursor()
        email=request.POST.get('email')
        mobno=request.POST.get('mobno')
        cl=request.POST.get('cl')
        ten=request.POST.get('ten')
        p=request.POST.get('plustwo')
        s=request.POST.get('sem')
        sql="UPDATE student SET mobno='%s',class='%s',ten='%s',plustwo='%s',sem='%s' WHERE email='%s'" % (mobno,cl,ten,p,s,request.session['email'])
        cursor.execute(sql)
        html = "<script>alert('successfully updated! ');window.location='/student/Studlogin/';</script>"
        return HttpResponse(html)
    else:
        list=[]
        cursor = connection.cursor()
        sql = "SELECT * FROM student WHERE email='%s'" % (request.session['email'])
        cursor.execute(sql)
        m=cursor.fetchall()
        for i in m:
            dict={'gender':i[2],'email':i[3], 'mobno':i[4], 'class':i[6], 'ten':i[8], 'plustwo':i[9], 'sem':i[10], 'question':i[11],'answer':i[12]}
            list.append(dict)
        return render(request, 'student/view.html', {'list':list})
def start(request):
    if request.method=='POST':
        cursor = connection.cursor()
        u = request.POST.get('email')
        p = request.POST.get('password')
        print(u,p)
        sql1 = "select * from student where email='%s' and password='%s'" % (u, p)
        cursor.execute(sql1)
        if cursor.rowcount > 0:
            request.session['email'] = u
            request.session['password'] = p
            return render(request, 'student/Regi.html')
        else:
            html = "<script>alert('Sorry you can't login! ');window.location='/student/start/';</script>"
            return HttpResponse(html)
    return render(request, 'student/start.html')
def view(request):
    list=[]
    cursor = connection.cursor()
    sql = "SELECT * FROM student WHERE email='%s'" % (request.session['email'])
    cursor.execute(sql)
    m=cursor.fetchall()
    for i in m:
        dict={'stud_id':i[0], 'name':i[1], 'gender':i[2], 'email':i[3], 'mobno':i[4], 'dpt': i[5], 'class':i[6]}
        list.append(dict)
    return render(request, 'student/view.html', {'list':list})

def internalmarks(request):
    list=[]
    cursor=connection.cursor()
    sql=" SELECT * FROM mark where studid='%s'" % (request.session.get('password'))
    cursor.execute(sql)
    m=cursor.fetchall()
    for i in m:
        dict={'sub': i[2],'first': i[5],'second': i[6],'ass': i[7],'project': i[8]}
        s=int(dict['first'])+int(dict['second'])+int(dict['ass'])+int(dict['project'])
        dict.update({'sum':s})
        list.append(dict)
    print(list)
    return render(request, 'student/internalmarks.html', {'list':list})

##################################################################################### Prediction Result ###############################################################################################

def presult(request):
    list = []
    cursor = connection.cursor()
    sql = " SELECT * FROM mark where studid='%s'" % (request.session.get('password'))
    cursor.execute(sql)
    m = cursor.fetchall()
    dict={}
    for i in m:
        dict = {'sub': i[2], 'first': i[5], 'second': i[6], 'ass': i[7], 'project': i[8]}
        s = int(dict['first']) + int(dict['second']) + int(dict['ass']) + int(dict['project'])
        dict.update({'sum': s})
        list.append(dict)
    print(list)
    d={}
    li=[]
    for i in list:
        print(i)
        if(i['sum']>=34):
            d=({'pass': 'Above 80%', 'chance':'Chance of Pass Good'})
            print('hi')
            li.append(d)
        elif(i['sum']>=28):
            d=({'pass': 'Above 70%','chance':'Chance of Pass Medium'})
            li.append(d)
        elif(i['sum']>=24):
            d=({'pass':'Above 60%','chance':'Chance of Failure Low'})
            li.append(d)
        elif (i['sum'] >= 20):
            d=({'pass': 'Above 50%','chance':'Possiblity for Failure'})
            li.append(d)
        elif (i['sum'] >= 16):
            d=({'pass': 'Above 40%','chance':'Chance of Failure Medium'})
            li.append(d)
        else:
            d=({'pass': 'Below 40%', 'chance':'Chance of Failure High'})
            li.append(d)
    return render(request, 'student/presult.html', {'li':li})