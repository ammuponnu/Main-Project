from django.conf.urls import url
from student import views

urlpatterns = [
    url(r'studlogin/$', views.studlogin, name="studlogin"),
    url(r'start$', views.start, name="start"),
    url(r'Regi/$', views.Regi, name="Regi"),
    url(r'view/$', views.view, name="view"),
    url(r'update/$', views.update, name="update"),
    url(r'internalmarks/$', views.internalmarks, name="internalmarks"),
    url(r'presult/$', views.presult, name="presult")

]