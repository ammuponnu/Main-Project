from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.test1, name='test1'),
    url(r'demo/$', views.demo, name='demo'),
    url(r'test1/$', views.test1, name='test1'),

]