from django.shortcuts import render, redirect, HttpResponse, HttpResponseRedirect
from django.db import connection
# Create your views here.

################################################################################################################# exam code ############################################################################################################

def test1(request):
    if request.method=='GET':
        cursor = connection.cursor()
        sql = "SELECT * FROM quest WHERE cname IN(SELECT class FROM student WHERE email='%s')" % (request.session['email'])
        cursor.execute(sql)
        m = cursor.fetchall()
        list = []
        for i in m:
            dict = {'question': i[1], 'ans1': i[2], 'ans2': i[3], 'ans3': i[4], 'ans4': i[5]}
            list.append(dict)
        return render(request, 'exams/test1.html', {'list': list})
    else:
        q = request.POST.get('q')
        a = request.POST.get('a')
        cursor = connection.cursor()
        sql = "insert into question(qname,ans) values('%s','%s')" % (q, a)
        cursor.execute(sql)
        html = "<script>alert('successfully saved! ');window.location='exams/test1/';</script>"
        return HttpResponse(html)

########################################################################################################## demo code ##########################################################################################
def demo(request):
    return render(request, 'exams/demo.html')